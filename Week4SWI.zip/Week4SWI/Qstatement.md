# Create a Dynamic Web App Using Flask:

#### Create a voting page that takes up user's information and vote and then displays it on the screen.

## Things to learn:
1. Flask
2. Routing with Flask
3. HTTP methods and their uses
4. HTML forms
5. Flask methods like render_template, redirect, request

